const http = require('http');
const fs = require('fs');
const path = require('path');

// Store messages for each channel
const messages = {
  'general': [],
  'homework': [],
  'school': [],
  'random': []
};

// Create server
const server = http.createServer((req, res) => {
  const url = req.url;
  const method = req.method;

  // Enable CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (url === '/' || url === '/index.html') {
    // Serve the HTML file
    fs.readFile(path.join(__dirname, 'index.html'), (err, data) => {
      if (err) {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('File not found');
        return;
      }
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(data);
    });

  } else if (url === '/style.css') {
    // Serve CSS file
    fs.readFile(path.join(__dirname, 'style.css'), (err, data) => {
      if (err) {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('File not found');
        return;
      }
      res.writeHead(200, { 'Content-Type': 'text/css' });
      res.end(data);
    });

  } else if (url.startsWith('/messages/')) {
    // Get messages for a channel
    const channel = url.split('/')[2];
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(messages[channel] || []));

  } else if (url === '/send' && method === 'POST') {
    // Receive new message
    let body = '';
    req.on('data', chunk => {
      body += chunk;
    });

    req.on('end', () => {
      try {
        const data = JSON.parse(body);
        const { channel, username, message } = data;

        if (messages[channel]) {
          messages[channel].push({
            username: username,
            message: message,
            timestamp: new Date().toLocaleTimeString()
          });

          // Keep only last 50 messages
          if (messages[channel].length > 50) {
            messages[channel] = messages[channel].slice(-50);
          }
        }

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true }));
      } catch (error) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid JSON' }));
      }
    });

  } else {
    // 404 for other requests
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not found');
  }
});

// Start server
const PORT = 5000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`Chat server running on port ${PORT}`);
  console.log(`Open http://localhost:${PORT} to start chatting!`);
});